import React from 'react';

const Board = () => {
    return (
        <div>게시물 보기</div>
    )
}

export default Board;