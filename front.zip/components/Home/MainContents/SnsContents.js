import React from "react";

import styles from "./snscontents.module.scss";

const SnsContents = () => {
  return (
    <article className={styles.snsContentsWrapper}>
      <div className={styles.headingWrpper}>
        <h4>📷 인스타그램 리뷰</h4>
      </div>
      <ul className={styles.snsContents}>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
        <li>
          <img src="# " alt="제품" />
        </li>
      </ul>
    </article>
  );
};

export default SnsContents;
